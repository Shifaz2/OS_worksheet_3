#include <stdio.h>
#include <syscall.h>

int
main (void)
{
    printf("Hello, World\n");
    
    return EXIT_SUCCESS;
}
